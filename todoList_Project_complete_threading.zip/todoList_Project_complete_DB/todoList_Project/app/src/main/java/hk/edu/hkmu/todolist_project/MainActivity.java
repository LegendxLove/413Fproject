package hk.edu.hkmu.todolist_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import hk.edu.hkmu.todolist_project.AboutActivity;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String> items;
    private ListView list;
    private Button button;
    private ArrayAdapter<String> itemsAdapter;
    private TodoListDatabaseHelper databaseHelper;
    private SQLiteDatabase database;
    private RadioGroup radioGroupDifficulty;
    private RadioGroup radioGroupUrgent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //database
        databaseHelper = new TodoListDatabaseHelper(this);
        database = databaseHelper.getWritableDatabase();

        //RadioGroup
        radioGroupDifficulty = findViewById(R.id.radioGroupDifficulty);
        radioGroupUrgent = findViewById(R.id.radioGroupUrgent);
        //list and button
        list = findViewById(R.id.list);
        button = findViewById(R.id.addButton);

        //click add button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onAddButtonClick(view);
            }
        });

        //list
        items = new ArrayList<>();
        itemsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        list.setAdapter(itemsAdapter);

        //longClick to delete
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                String selectedListName = itemsAdapter.getItem(position);
                return remove(selectedListName, position);
            }
        });
    }

    //close database
    @Override
    protected void onDestroy() {
        super.onDestroy();
        database.close();
    }

    //create menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_about) {
            // Launch the AboutActivity
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //add item
    private void onAddButtonClick(View view) {
        // Get item value
        EditText input = findViewById(R.id.edit_text);
        String itemText = input.getText().toString();
        // Get urgency value
        RadioButton selectedUrgentRadioButton = findViewById(radioGroupUrgent.getCheckedRadioButtonId());
        String urgency = selectedUrgentRadioButton.getText().toString();
        // Get difficulty value
        RadioButton selectedDifficultyRadioButton = findViewById(radioGroupDifficulty.getCheckedRadioButtonId());
        String difficulty = selectedDifficultyRadioButton.getText().toString();

        if (!(itemText.equals(""))) {
            //insert record into table
            ContentValues values = new ContentValues();
            values.put("difficulty", difficulty);
            values.put("urgent", urgency);
            values.put("list_name", itemText);
            database.insert("todoList", null, values);

            //item + urgency + difficulty
            String todolistName = itemText + " - " + difficulty + " - " + urgency;

            //add item into list
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    itemsAdapter.add(todolistName);
                }
            });

            //clear content
            input.setText("");

        }
        else{
            Toast.makeText(getApplicationContext(), "", Toast.LENGTH_LONG).show();
        }
    }

    //remove item
    private boolean remove(String listName, int position) {
        //delete item from list
        String selection = "list_name = ?";
        String[] selectionArgs = {listName};
        database.delete("todoList", selection, selectionArgs);
        //show toast message
        Context context = getApplicationContext();
        Toast.makeText(context, "Work removed", Toast.LENGTH_SHORT).show();
        //remove item
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context, "Work removed", Toast.LENGTH_SHORT).show();
                //remove item
                items.remove(position);
                itemsAdapter.notifyDataSetChanged();
            }
        });
        return true;
    }
}